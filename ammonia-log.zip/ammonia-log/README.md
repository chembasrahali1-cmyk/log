# سجل قراءات قسم الأمونيا — Ammonia Unit Daily Readings Log

Single-file app (`index.html`): HTML + CSS + vanilla JS, Arabic RTL, no build step, no dependencies.

## Current structure
- 5 plant sections (array `S` in the script): 100 (steam/BFW, reformer, shift/methanation), 200 (CO2 removal/Catacarb), 300 (all compressors: K-303, K-302, K-301, K-401, K-501), 400 (ammonia synthesis, refrigeration, separation), 700 (cooling tower).
- Each section is a template string `d` of lines `TAG|description`; a line `#|title` creates a sub-heading.
- Units are derived from the tag in `unit()`.
- Shifts: 24h, 12h day, 12h night, 8h (readings every 2 hours).
- Records are stored in `localStorage` under keys `rd2:<date>|<shift>[|<start>]`. Reading key format: `slot|sectionIndex|tag`.
- `mig()` migrates old (9-section) records to the 5-section layout.
- Features: search (tag, description, type such as temperature/pressure/controller), archive, JSON export/import/merge, A4 landscape print per shift or per section.

## Planned next steps (handover to the company)
1. Central storage (e.g. Firebase Firestore) instead of per-browser `localStorage`, with automatic backup.
2. User accounts for operators + audit log (who entered/edited which reading and when).
3. Shift sign-off by operator and supervisor, then lock the record (no edits).
4. Archive: search by date/shift/operator; export PDF and Excel per shift/month.
5. Data quality: normal ranges per tag with highlighting, block closing a shift with missing readings, accept `+OVER` / `-OVER`.
6. PWA (offline use in the control room, installable), short user guide.

Keep the UI Arabic RTL, mobile friendly, and keep the existing data model compatible (or migrate it).
